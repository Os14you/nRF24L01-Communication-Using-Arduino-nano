Use the same coloured dupont wires as in these two photos to check wiring.
